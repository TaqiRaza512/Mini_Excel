#pragma once
#include<string>
#include<Windows.h>
#include<iostream>
using namespace std;
class MiniExcel
{
private:
	class Cell
	{
	private:
		friend class MiniExcel;
		Cell *Right,*Left,*Up,*Down;
		string Data;
		int row, col;
	public:
		Cell(int Ro = 0, int C = 0,string D = "", Cell* R = nullptr, Cell* L = nullptr, Cell* U = nullptr, Cell* Dn = nullptr)
		{
			row = Ro;
			col = C;
			Data = D;
			Right = R;
			Left = L;
			Up = U;
			Down = Dn;
		}
	};
	Cell* Current;
	Cell* Head;
	Cell* Tail;
	int currentRow;
	int currentCol;
	int NofRows;
	int NofCols;
public:
	MiniExcel();
	//Connecting pointers
	void ConnectingUp(Cell* Current, Cell* Up);
	void ConnectingDown(Cell* Current, Cell* Down);
	void ConnectingRight(Cell* Current, Cell* Right);
	void ConnectingLeft(Cell* Current, Cell* Left);
	//Current
	bool IsMostAbove(Cell* Current);
	bool IsMostRight(Cell* Current);
	bool IsMostDown(Cell* Current);
	bool IsMostLeft(Cell* Current);
	void MoveCurrentToTop();
	void MoveCurrentToDown();
	void MoveCurrentToLeft();
	void MoveCurrentToRight();
	//MainFunctions
	void InsertColToRight();
	void InsertRowBelow();

	void PrintingGrid();
	void Print();
	//Cells
	void PrintingCell(int r,int c);
	//Pointer
	void MovePointerToRight(Cell*& Pointer);
	void MovePointerToUp(Cell*& Pointer);
	void MovePointerToDown(Cell*& Pointer);
	void MovePointerToLeft(Cell*& Pointer);
};

