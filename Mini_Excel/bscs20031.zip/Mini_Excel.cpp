#include<iostream>
#include"MiniExcel.h"
#include"Header1.h"
using namespace std;

int main()
{
	MiniExcel E;
	//E.Print();
	E.PrintingGrid();
	

}
