#include "MiniExcel.h"
#include"Header1.h"
#include<iostream>
int Cell_ColumnSize = 8;
int Cell_RowSize = 15;
void color(int k)
{
	if (k > 255)
	{
		k = 1;
	}
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hConsole, k);

}
void getRowColbyLeftClick(int& rpos, int& cpos)
{
	HANDLE hInput = GetStdHandle(STD_INPUT_HANDLE);
	DWORD Events;
	INPUT_RECORD InputRecord;
	SetConsoleMode(hInput, ENABLE_PROCESSED_INPUT | ENABLE_MOUSE_INPUT | ENABLE_EXTENDED_FLAGS);
	do
	{
		ReadConsoleInput(hInput, &InputRecord, 1, &Events);
		if (InputRecord.Event.MouseEvent.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED)
		{
			cpos = InputRecord.Event.MouseEvent.dwMousePosition.X;
			rpos = InputRecord.Event.MouseEvent.dwMousePosition.Y;
			break;
		}
	} while (true);
}
void gotoRowCol(int rpos, int cpos)
{
	COORD scrn;
	HANDLE hOuput = GetStdHandle(STD_OUTPUT_HANDLE);
	scrn.X = cpos;
	scrn.Y = rpos;
	SetConsoleCursorPosition(hOuput, scrn);
}
MiniExcel::MiniExcel()
{
	NofRows = NofCols = 1;
	Head = Current = new Cell(0, 0);
	currentRow = currentCol = 0;
	int i = 0;
	while (i <10)
	{
		InsertColToRight();
		Current = Current->Right;
		currentCol++;
		i++;
	}
	i = 0;
	while (i<10)
	{
		InsertRowBelow();
		Current = Current->Down;
		currentRow++;
		i++;
	}
}
void MiniExcel::ConnectingUp(Cell*Current, Cell*Up)
{
		Current->Up = Up;
}
void MiniExcel::ConnectingDown(Cell* Current, Cell* Down)
{
	Current->Down = Down;
}
void MiniExcel::ConnectingRight(Cell*Current,Cell*Right)
{
	Current->Right = Right;
}
void MiniExcel::ConnectingLeft(Cell* Current, Cell* Left)
{
	Current->Left= Left;
}
bool MiniExcel::IsMostAbove(Cell*Current)
{
	if (Current->Up==nullptr)
	{
		return true;
	}
	return false;
}
bool MiniExcel::IsMostRight(Cell* Current)
{
	if (Current->Right== nullptr)
	{
		return true;
	}
	return false;
}
bool MiniExcel::IsMostDown(Cell* Current)
{
	if (Current->Down== nullptr)
	{
		return true;
	}
	return false;
}
bool MiniExcel::IsMostLeft(Cell* Current)
{
	if (Current->Left== nullptr)
	{
		return true;
	}
	return false;
}
void MiniExcel::MoveCurrentToTop()
{
	while (Current!=nullptr and Current->Up!=nullptr)
	{
		Current = Current->Up;
		currentRow--;
	}
}
void MiniExcel::MoveCurrentToDown()
{
	while (Current->Down!= nullptr)
	{
		Current = Current->Down;
		currentRow++;

	}
}
void MiniExcel::MoveCurrentToLeft()
{
	while (Current!=nullptr and  Current->Left!= nullptr)
	{
		Current = Current->Left;
		currentCol--;
	}
}
void MiniExcel::MoveCurrentToRight()
{
	while (Current->Right!= nullptr)
	{
		Current = Current->Right;
		currentCol++;
	}
}
void MiniExcel::MovePointerToRight(Cell*& Pointer)
{
	while (Pointer != nullptr and Pointer->Right!= nullptr)
	{
		Pointer = Pointer->Right;
	}
}
void MiniExcel::MovePointerToUp(Cell*& Pointer)
{
	while (Pointer != nullptr and Pointer->Up != nullptr)
	{
		Pointer = Pointer->Up;
	}
}
void MiniExcel::MovePointerToDown(Cell*& Pointer)
{
	while (Pointer != nullptr and Pointer->Down != nullptr)
	{
		Pointer = Pointer->Down;
	}
}
void MiniExcel::MovePointerToLeft(Cell*& Pointer)
{
	while (Pointer != nullptr and Pointer->Left!= nullptr)
	{
		Pointer = Pointer->Left;
	}
}
void MiniExcel::InsertColToRight()
{
	MoveCurrentToTop();
	Cell* Temp;
	while (Current != nullptr)
	{
		Temp = new Cell(currentRow,currentCol+1);
		Temp->Left = Current;
		Temp->Right = Current->Right;
		Current->Right = Temp;
		if (Current->Down != nullptr)
		{
			Current = Current->Down;
			currentRow++;
		}
		else
		{
			break;
		}
	}
	NofCols++;
}
void MiniExcel::InsertRowBelow() 
{
	MoveCurrentToLeft();
	Cell* Temp,*Below,*Previous=nullptr,*After=nullptr;
	while (Current != nullptr)
	{
		Temp = new Cell(currentRow+1, currentCol);
		Temp->Down = Current->Down;
		Current->Down = Temp;
		Below = Temp->Down;
		if(Below!=nullptr)
			Below->Up = Temp;
		Temp->Up = Current;
		Temp->Left = Previous;
		if (Previous != nullptr)
			Previous->Right = Temp;

		Temp->Right = After;

		if (Current->Right != nullptr)
		{
			Current = Current->Right;
			currentCol++;

		}
		else
		{
			break;
		}
		Previous = Temp;
	}
	NofRows++;
}
void MiniExcel::Print()
{
	cout << NofRows << ":" << NofCols << endl;
	while (Head!=nullptr)
	{

		while (Head != nullptr)
		{
			cout << Head << "=>"<<"("<<Head->row<<","<<Head->col<<")";
			cout << Head->Up << "," << Head->Left << "," << Head->Right << "," << Head->Down;
			cout << "         ";
			if (Head->Right != nullptr)
				Head = Head->Right;
			else
				break;
		}
		MovePointerToLeft(Head);
		if (Head->Down != nullptr)
			Head = Head->Down;
		else
			break;
		cout << endl;
	}
	MovePointerToLeft(Head);
	MovePointerToUp(Head);

}
void MiniExcel::PrintingGrid()
{
	MovePointerToUp(Head);
	MovePointerToLeft(Head);
	for (int r=0;r<NofRows;r++)
	{
		for (int c = 0; c < NofCols; c++)
		{
			PrintingCell(r,c);
			if(Head->Right)
				Head = Head->Right;
			cout << endl;
		}
		if (Head->Down)
		{
			Head = Head->Down;
			MovePointerToLeft(Head);
		}
		
	}
	color(3);
	MoveCurrentToTop();
	PrintingCell(currentRow,currentCol);
	gotoRowCol(NofCols * 8,0);
}
void MiniExcel::PrintingCell(int r,int c)
{
	int rpos1 = r * Cell_ColumnSize -r;
	int cCol1 = c * Cell_RowSize -c;
	int rpos2 = rpos1+ Cell_ColumnSize -1;
	int cCol2 = cCol1+ Cell_RowSize -1;
	for (int ri=rpos1;ri<=rpos2;ri++)
	{
		gotoRowCol(ri, cCol1);
		cout << char(-37);
		gotoRowCol(ri, cCol2);
		cout << char(-37);
	}
	gotoRowCol(((rpos1 + rpos2) / 2)+1, ((cCol1 + cCol2) / 2)-1);
	cout << Head->Data;
	for (int ci = cCol1; ci <= cCol2; ci++)
	{

		gotoRowCol(rpos1, ci);
		cout << char(-37);
		gotoRowCol(rpos2, ci);
		cout << char(-37);
	}

}
